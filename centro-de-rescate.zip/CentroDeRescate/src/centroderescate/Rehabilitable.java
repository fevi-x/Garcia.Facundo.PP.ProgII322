package centroderescate;

/**
 * Interfaz para animales que pueden recibir rehabilitacion
 * @author Facundo Garcia
 */
public interface Rehabilitable {
    /**
     * Inicia el proceso de rehabilitacion
     * @return 
     */
    public String rehabilitar();
}
