package centroderescate;


/**
 * Representa un animal de tipo mamifero. Subclase de Animal
 * @author Facundo Garcia
 */
public class Mamifero extends Animal implements Rehabilitable {
    private final int peso;
    private final static int MANTENIMIENTO_MAMIFERO = 10;

    /**
     * Crea un nuevo Mamifero
     * @param codigo codigo de identificacion
     * @param nombre nombre del mamifero
     * @param estadoSalud EstadoSalud salud del mamifero
     * @param peso peso del mamifero
     */
    public Mamifero(String codigo, String nombre, EstadoSalud estadoSalud, int peso) {
        super(codigo, nombre, estadoSalud);
        validarPeso(peso);
        this.peso = peso;
    }
    
    private void validarPeso(int peso) {
        if (peso < 0) {
            throw new IllegalArgumentException("El peso debe ser un entero positivo");
        }
    }

    public int getPeso() {
        return peso;
    }

    @Override
    public int costoDiario() {
        return peso * MANTENIMIENTO_MAMIFERO;
    }

    @Override
    public String rehabilitar() {
        return "El mamifero " + getNombre() + " esta en rehabilitaccion.";
    }
    
    @Override
    public String toString() {
        return "Mamifero{" + super.toString() + ", peso=" + peso + '}';
    }
    
}
