package centroderescate;


/**
 * Representa un animal de tipo ave. Subclase de Animal
 * @author Facundo Garcia
 */
public class Ave extends Animal implements Liberable, Rehabilitable {
    private final int envergaduraAlar;
    private final static int MANTENIMIENTO_AVE = 2;

    /**
     * Crea una nueva ave
     * @param codigo codigo de identificacion
     * @param nombre nombre del ave
     * @param estadoSalud EstadoSalud salud del ave
     * @param envergaduraAlar tamaño de la envergadura alar del ave
     */
    public Ave(String codigo, String nombre, EstadoSalud estadoSalud, int envergaduraAlar) {
        super(codigo, nombre, estadoSalud);
        validarEnvergaduraAlar(envergaduraAlar);
        this.envergaduraAlar = envergaduraAlar;
    }

    public int getEnvergaduraAlar() {
        return envergaduraAlar;
    }

    private void validarEnvergaduraAlar(int envergaduraAlar) {
        if (envergaduraAlar < 0) {
            throw new IllegalArgumentException("La envergadura alar debe ser un entero positivo");
        }
    }
    
    @Override
    public int costoDiario() {
        return envergaduraAlar * MANTENIMIENTO_AVE;
    }

    @Override
    public String liberar() {
        return "El ave " + getNombre() + " esta en proceso de liberacion.";
    }

    @Override
    public String rehabilitar() {
        return "El ave " + getNombre() + " esta en rehabilitaccion.";
    }
    
    @Override
    public String toString() {
        return "Ave{" + super.toString() + ", envergaduraAlar=" + envergaduraAlar + '}';
    }
    
}
