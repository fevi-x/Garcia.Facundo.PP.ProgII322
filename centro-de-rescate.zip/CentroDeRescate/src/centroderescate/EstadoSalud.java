package centroderescate;

/**
 * Estado de salud del animal
 * @author Facundo Garcia
 */
public enum EstadoSalud {
    CRITICO,
    EN_RECUPERACION,
    ESTABLE;
}
