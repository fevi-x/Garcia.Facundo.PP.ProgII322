package centroderescate;

/**
 * Interfaz para animales que pueden realizar un proceso de liberacion
 * @author Facundo Garcia
 */
public interface Liberable {
    
    /**
     * Inicia el proceso de liberacion
     * @return 
     */
    public String liberar();
}
