package centroderescate;

import java.util.Objects;


/**
 * Animal generico del cual pueden crearse distintos tipos de animales
 * @author Facundo Garcia
 */
public abstract class Animal {
    private final String codigo;
    private final String nombre;
    private final EstadoSalud estadoSalud;

    public Animal(String codigo, String nombre, EstadoSalud estadoSalud) {
        Objects.requireNonNull(codigo);
        Objects.requireNonNull(nombre);
        Objects.requireNonNull(estadoSalud);
        validarCodigo(codigo);
        validarNombre(nombre);
        this.codigo = codigo;
        this.nombre = nombre;
        this.estadoSalud = estadoSalud;
    }

    private void validarCodigo(String codigo) {
        if (codigo.isEmpty() || codigo.isBlank()) {
            throw new IllegalArgumentException("Debe pasar un codigo valido");
        }
    }
    
    private void validarNombre(String nombre) {
        if (nombre.isEmpty() || nombre.isBlank()) {
            throw new IllegalArgumentException("Debe pasar un nombre valido");
        }
    }
    
    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public EstadoSalud getEstadoSalud() {
        return estadoSalud;
    }
    
    /**
     * Calcula el costo de mantenimiento del animal
     * @return 
     */
    public abstract int costoDiario();

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 13 * hash + Objects.hashCode(this.codigo);
        hash = 13 * hash + Objects.hashCode(this.nombre);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        
        if (!(obj instanceof Animal otro)) {
            return false;
        }
        
        return Objects.equals(this.codigo, otro.codigo) && 
                Objects.equals(this.nombre, otro.nombre);
    }

    @Override
    public String toString() {
        return "codigo=" + codigo + ", nombre=" + nombre + ", estadoSalud=" + estadoSalud;
    }
    
    
}
