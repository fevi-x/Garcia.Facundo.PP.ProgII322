package centroderescate;


/**
 * Representa un animal de tipo reptil. Subclase de Animal
 * @author Facundo Garcia
 */
public class Reptil extends Animal implements Liberable {
    private final int longitud;
    private final static int MANTENIMIENTO_REPTIL = 15;

    /**
     * Crea un nuevo reptil
     * @param codigo codigo de identificacion
     * @param nombre nombre del reptil
     * @param estadoSalud EstadoSalud salud del reptil
     * @param longitud longitud del reptil
     */
    public Reptil(String codigo, String nombre, EstadoSalud estadoSalud, int longitud) {
        super(codigo, nombre, estadoSalud);
        validarLongitud(longitud);
        this.longitud = longitud;
    }

    private void validarLongitud(int longitud) {
        if (longitud < 0) {
            throw new IllegalArgumentException("La longitud debe ser un entero positivo");
        }
    }
    
    public int getLongitud() {
        return longitud;
    }
    
    @Override
    public int costoDiario() {
        return longitud + MANTENIMIENTO_REPTIL;
    }

    @Override
    public String liberar() {
        return "El reptil " + getNombre() + " esta en proceso de liberacion.";
    }

    @Override
    public String toString() {
        return "Reptil{" + super.toString() + ", longitud=" + longitud + '}';
    }
    
    
    
}
