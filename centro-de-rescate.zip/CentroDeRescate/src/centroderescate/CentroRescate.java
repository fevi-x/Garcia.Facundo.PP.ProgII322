package centroderescate;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

/**
 * Centro de Rescate que contiene un listado de animales y metodos de filtrado
 * para obtener informacion.
 * @author Facundo Garcia
 */
public class CentroRescate {
    private final String nombre;
    private final List<Animal> animales;

    /**
     * Crea un nuevo Centro de Rescate.
     * @param nombre nombre asignado al centro de rescate.
     */
    public CentroRescate(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre;
        animales = new ArrayList<>();
    }

    private void validarNombre(String nombre) {
        if (nombre.isEmpty() || nombre.isBlank()) {
            throw new IllegalArgumentException("El nombre no puede estar vacio.");
        }
    }
    
    public String getNombre() {
        return nombre;
    }

    public List<Animal> getAnimales() {
        return animales;
    }
    
    /**
     * Agrega un nuevo animal al Centro de Rescate
     * @param animal animal nuevo
     * @throws AnimalDuplicadoException si el animal ya existe
     */
    public void agregarAnimal(Animal animal) throws AnimalDuplicadoException {
        Objects.requireNonNull(animal);
        validarAnimalDuplicado(animal);
        animales.add(animal);
    }
    
    private void validarAnimalDuplicado(Animal animal) throws AnimalDuplicadoException {
        for (Animal a : animales) {
            if (a.equals(animal)) {
                throw new AnimalDuplicadoException("Ya existe el animal " + 
                        a.getNombre() + " con codigo " + a.getCodigo());
            }
        }
    }
    
    /**
     * Lista de animales guardados
     * @return copia de la lista de animales guardados
     */
    public List<Animal> obtenerAnimales() {
        return new ArrayList<>(animales);
    }
    
    /**
     * Filtra los animales en base al EstadoSalud indicado
     * @param estado EstadoSalud de los animales a buscar
     * @return lista de animales filtrados por el estado de salud
     */
    public List<Animal> filtrarPorEstado(EstadoSalud estado) {
        Objects.requireNonNull(estado);
        
        ArrayList<Animal> resultado = new ArrayList<>();
        
        Iterator<Animal> it = animales.iterator();
        
        while (it.hasNext()) {
            Animal animal = it.next();
            
            if (animal.getEstadoSalud() == estado) {
                resultado.add(animal);
            }
        }

        return resultado;
    }
    
    /**
     * Filtra los animales por costo maximo
     * @param maximo indica el costo maximo de mantenimiento de los animales
     * @return lista de animales filtrados en base al costo maximo ingresado
     */
    public List<Animal> obtenerAnimalesConCostoMaximo(int maximo) {
        if (maximo <= 0) {
            throw new IllegalArgumentException("El máximo debe ser mayor que cero");
        }
        
        
        ArrayList<Animal> resultado = new ArrayList<>();
        
        for (Animal a : animales) {
            if (a.costoDiario() <= maximo) {
                resultado.add(a);
            }
        }

        return resultado;
    }
}
