package centroderescate;


/**
 * En caso de que el animal ya exista en la lista
 * @author Facundo Garcia
 */
public class AnimalDuplicadoException extends Exception {

    public static final String DEFAULT_MENSAJE = "Animal duplicado";
    
    public AnimalDuplicadoException() {
        this(DEFAULT_MENSAJE);
    }

    
    public AnimalDuplicadoException(String msg) {
        super(msg);
    }
}
